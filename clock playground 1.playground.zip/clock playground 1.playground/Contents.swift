import UIKit

let object = "egg"
var eggTimer = 0


let endTime = 179


for eggTimer in 0...179{
    print ("\(eggTimer + 1)")
    if eggTimer >= endTime {
print ("your egg is done")

}
    if eggTimer == 149 {
        print ("thirty seconds before egg is done")
    }
}
